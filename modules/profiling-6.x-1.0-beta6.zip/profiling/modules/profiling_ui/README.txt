
Profiling UI
============

Provide comprehensive report pages displaying timers statistics.

Installation
------------

Enable the module. A new administration section called "Profiling" will appear
in your administration pages.

Graphical reports
-----------------

If you want additional graphical charts to be displayed, download and install
the Charts module at http://drupal.org/project/charts

This module charts fits with default charts module configuration configuration
using google backend seamlessly.
