<?php

/**
 * @file
 * Profiling report item default template.
 * 
 * Please don't override unless you really need it because of a custom theme
 * incompatiblity.
 */
?>
<div class="<?php print $classes; ?>">
  <h3><?php print $title; ?></h3>
  <?php print $content; ?>
</div>
