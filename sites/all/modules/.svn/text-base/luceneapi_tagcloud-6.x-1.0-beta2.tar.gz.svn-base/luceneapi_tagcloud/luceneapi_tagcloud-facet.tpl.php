<?php
// $Id: luceneapi_tagcloud-facet.tpl.php,v 1.2 2009/12/19 03:10:47 cpliakas Exp $

/**
 * @file luceneapi_tagcloud-results.tpl.php
 * Default theme implementation for displaying a tagcloud facet inside of the
 * Search Lucene Tagcloud blocks.
 *
 * Available variables:
 * - $facet_name: The name of the facet.
 * - $facets: The facet links.
 * - $type: The type of search, e.g., "luceneapi_node".
 *
 * @see template_preprocess_luceneapi_tagcloud_facet()
 */
?>
<?php if ($facet_name): ?>
  <h3><?php print $facet_name; ?></h3>
<?php endif; ?>
<div class="wrapper">
  <?php print $facets; ?>
</div>