This module has no UI of its own and unless some other module uses it,
it won't appear to add anything to your site. Only bother with this module
if some other module tells you to.