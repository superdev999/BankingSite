ad_flash is a plugin for the ad module (http://drupal.org/project/ad) that
allows the use of flash banners for advertising.

The module is now maintained by cris.cohen (http://drupal.org/user/306375) and alex_andrascu (http://drupal.org/user/429248).