
Welcome to Views 3. Please see the advanced help for more information.

If you're having trouble installing this module, please ensure that your
tar program is not flattening the directory tree, truncating filenames
or losing files.

Installing Views:

Place the entirety of this directory in sites/all/modules/views

Navigate to administer >> build >> modules. Enable Views and Views UI.

If you're new to Views, try the Simple Views module which can create some
often used Views for you, this might save you some time.

Recommended modules for use with Views:
  CCK
  Voting API
  Views Bonus Pack
  Views Bulk Operations

Experimental modules:
  Views OR
